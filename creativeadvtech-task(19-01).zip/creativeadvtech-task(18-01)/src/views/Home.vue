<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <!-- <img alt="logo" src="../assets/EarthlinkLogo.svg">
    <img alt="flower" src="../assets/flower.svg">
    <img alt="folder" src="../assets/folder.svg">
    <img alt="bell" src="../assets/bell.svg">
    <img alt="customer" src="../assets/customer.svg">
    <img alt="down-arrow" src="../assets/down-arrow.svg"> -->
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'Home'
})
</script>
